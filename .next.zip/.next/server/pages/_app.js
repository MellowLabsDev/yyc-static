(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 1198:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ MyApp)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
;// CONCATENATED MODULE: ./components/Nav.tsx




function NavComponent() {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Navbar, {
            className: "fixed-top",
            expand: "lg",
            style: {
                justifyContent: "center",
                zIndex: "10"
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Container, {
                className: "mx-lg-5 gasc-nav-container",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Navbar.Brand, {
                        href: "/",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                alt: "",
                                src: "/images/logo.png",
                                width: "30",
                                height: "30",
                                className: "d-inline-block align-top"
                            }),
                            " ",
                            "Yeti Yacht Club"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Navbar.Toggle, {
                        "aria-controls": "basic-navbar-nav"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Navbar.Collapse, {
                        id: "basic-navbar-nav",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Nav, {
                            className: "ml-auto",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Nav.Link, {
                                    href: "/",
                                    children: "Home"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Nav.Link, {
                                    href: "/roadmap",
                                    children: "Roadmap"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Nav.Link, {
                                    href: "/story",
                                    children: "Story"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Nav.Link, {
                                    href: "/holderBenefits",
                                    children: "Holder Benefits"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Nav.Link, {
                                    href: "/team",
                                    children: "Team"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Nav.Link, {
                                    className: "navSocial",
                                    href: "https://twitter.com/OfficialYetiYC",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaTwitter, {})
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Nav.Link, {
                                    className: "navSocial",
                                    href: "https://discord.gg/yAVGGzWNSM",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaDiscord, {})
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Nav.Link, {
                                    className: "navSocial",
                                    href: "https://opensea.io/collection/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Image, {
                                        src: "/images/opensea.png",
                                        alt: "",
                                        width: "18px",
                                        height: "18px"
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const Nav = (NavComponent);

;// CONCATENATED MODULE: ./components/sections/Footer.tsx



function Footer() {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "footer-container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
                className: "py-3 my-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "nav justify-content-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "nav-item",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "https://twitter.com/OfficialYetiYC",
                                    className: "nav-link",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaTwitter, {
                                        size: "2.5rem"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "nav-item",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "https://discord.gg/yAVGGzWNSM",
                                    className: "nav-link",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaDiscord, {
                                        size: "2.5rem"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "text-center",
                        children: [
                            "\xa9 Copyright | Yeti Yacht Club ",
                            new Date().getFullYear(),
                            " | All Rights Reserved"
                        ]
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const sections_Footer = (Footer);

;// CONCATENATED MODULE: ./components/layout.js



const Layout = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Nav, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(sections_Footer, {})
        ]
    });
};
/* harmony default export */ const layout = (Layout);

// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(4298);
var script_default = /*#__PURE__*/__webpack_require__.n(script);
;// CONCATENATED MODULE: ./pages/_app.js






function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                strategy: "lazyOnload",
                src: `https://www.googletagmanager.com/gtag/js?id=G-1W80PK42W8`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                id: "gtag1",
                strategy: "lazyOnload",
                children: `
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
              gtag('config', 'G-1W80PK42W8', {
              page_path: window.location.pathname,
              });
          `
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                strategy: "lazyOnload",
                async: true,
                src: "https://www.googletagmanager.com/gtag/js?id=G-1W80PK42W8"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                id: "gtag2",
                strategy: "lazyOnload",
                children: `
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());

          gtag('config', 'G-1W80PK42W8');
        `
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                id: "ttag1",
                strategy: "lazyOnload",
                children: `!function(e,t,n,s,u,a){e.twq||(s=e.twq=function(){s.exe?s.exe.apply(s,arguments):s.queue.push(arguments);
      },s.version='1.1',s.queue=[],u=t.createElement(n),u.async=!0,u.src='//static.ads-twitter.com/uwt.js',
      a=t.getElementsByTagName(n)[0],a.parentNode.insertBefore(u,a))}(window,document,'script');
      // Insert Twitter Pixel ID and Standard Event data below
      twq('init','o9bdq');
      twq('track','PageView');`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(layout, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps
                })
            })
        ]
    });
};


/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(699)


/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 358:
/***/ ((module) => {

"use strict";
module.exports = require("react-bootstrap");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [699], () => (__webpack_exec__(1198)));
module.exports = __webpack_exports__;

})();