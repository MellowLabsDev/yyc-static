"use strict";
exports.id = 953;
exports.ids = [953];
exports.modules = {

/***/ 9093:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function Hero(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            id: "hero",
            className: "hero mt-10" + " " + props.classname
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);


/***/ }),

/***/ 2779:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var aos__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9783);
/* harmony import */ var aos__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(aos__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__);






const teamMembers = [
    {
        id: 0,
        name: "David",
        title: "CEO/Co-Founder",
        desc: "",
        twitter: true,
        twitterHref: "https://twitter.com/davidjustin84",
        linkedin: true,
        linkedinHref: "https://www.linkedin.com/in/davidjwoodbury",
        img: "/images/team/david.png"
    },
    {
        id: 1,
        name: "Dan",
        title: "Marketing/Co-Founder",
        desc: "",
        twitter: true,
        twitterHref: "https://twitter.com/DansRoadToRichs",
        linkedin: true,
        linkedinHref: "https://www.linkedin.com/in/dan-comeau-1378a21a9/",
        img: "/images/team/dan.png"
    },
    {
        id: 2,
        name: "Noah",
        title: "Mellow Labs Developer/Executive Team",
        desc: "",
        twitter: true,
        twitterHref: "https://twitter.com/ElderPyke",
        linkedin: true,
        linkedinHref: "https://www.linkedin.com/in/nallenweb3/",
        img: "/images/team/noah.png"
    },
    {
        id: 3,
        name: "Arvin",
        title: "CMO",
        desc: "",
        twitter: true,
        twitterHref: "https://twitter.com/arvinknft",
        linkedin: true,
        linkedinHref: "https://www.linkedin.com/in/arvinkhamseh/",
        img: "/images/team/arvin.jpg"
    },
    {
        id: 4,
        name: "Alec",
        title: "Mellow Labs Developer",
        desc: "",
        twitter: true,
        twitterHref: "https://twitter.com/wutangdev",
        linkedin: true,
        linkedinHref: "https://www.linkedin.com/in/alecb/",
        img: "/images/team/alec.png"
    },
    {
        id: 5,
        name: "Meagan",
        title: "Community Manager",
        desc: "",
        twitter: true,
        twitterHref: "https://twitter.com/DogeGirl420",
        linkedin: false,
        linkedinHref: "",
        img: "/images/team/meagan.png"
    },
    {
        id: 4,
        name: "Ayesha",
        title: "Moderator",
        desc: "",
        twitter: true,
        twitterHref: "https://twitter.com/AShawThing_",
        linkedin: false,
        linkedinHref: "",
        img: "/images/team/ayesha.png"
    }, 
];
function TeamComponent() {
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        aos__WEBPACK_IMPORTED_MODULE_3___default().init({
            startEvent: "load",
            once: false
        });
    // AOS.refresh();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            id: "team",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "px-4 py-5 text-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "display-5 fw-bold ga-section-title",
                        children: "Team"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row team-row justify-content-center",
                        children: teamMembers.map((member)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-sm-6 col-lg-4 team-container",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Card, {
                                    "data-aos": "fade-up",
                                    style: {
                                        backgroundColor: "transparent",
                                        width: "18rem",
                                        margin: "auto",
                                        height: "100%",
                                        borderRadius: "0",
                                        border: "0",
                                        overflow: "hidden"
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Card.Img, {
                                            variant: "top",
                                            style: {
                                                borderRadius: "50px"
                                            },
                                            src: member.img
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Card.Body, {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Card.Title, {
                                                    children: member.name
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Card.Text, {
                                                    children: member.title
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                    className: "nav col-md-4 justify-content-center list-unstyled d-flex",
                                                    style: {
                                                        margin: "auto"
                                                    },
                                                    children: [
                                                        member.twitter == true ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                href: member.twitterHref,
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaTwitter, {
                                                                    size: "1.5rem"
                                                                })
                                                            })
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            style: {
                                                                width: 0
                                                            }
                                                        }),
                                                        member.linkedin == true ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                href: member.linkedinHref,
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaLinkedin, {
                                                                    size: "1.5rem"
                                                                })
                                                            })
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            style: {
                                                                width: 0
                                                            }
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }, member.id))
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TeamComponent);


/***/ })

};
;